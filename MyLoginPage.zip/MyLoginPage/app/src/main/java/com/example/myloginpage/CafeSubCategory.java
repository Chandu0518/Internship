package com.example.myloginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class CafeSubCategory extends AppCompatActivity {

    ListView cafeBrandListView;
    TextView cafeName;

    String[] items={""};

    Integer[] images;
    int[] logosint;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_sub_category);

        //set ids

        cafeBrandListView=findViewById(R.id.items_lv);
        cafeName=findViewById(R.id.items_tv);

        //receive the data

        items=getIntent().getStringArrayExtra("items");
        String CafeName=getIntent().getStringExtra("CafeName");
        logosint=getIntent().getIntArrayExtra("images");
        images=toConvertInteger(logosint);


        //Adapter



      //  CafeAdapter adapter=new CafeAdapter(this,items, );

        //cafeBrandListView.setAdapter(adapter);

        cafeName.setText(CafeName);

    }
    public static Integer[] toConvertInteger(int[] ids){
        Integer[] newArray =new Integer[ids.length];
        for (int i=0;i<ids.length;i++){
            newArray[i]=Integer.valueOf(ids[i]);
        }
        return newArray;
    }

}