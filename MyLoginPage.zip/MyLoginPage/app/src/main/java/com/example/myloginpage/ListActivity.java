package com.example.myloginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ListActivity extends AppCompatActivity {

    String[] cafe_names={"Jim Morrison Cafe","Landour Bakehouse","Beatles Cafe","Wake and Bake Cafe",
    "Glenary's","Cafe 1947","Cafe Chica","Illiterati Coffee","The Sakley’s","Cafe Simla Times","Little Llama Cafe",
    "Cloud Coffee","Rinchen Cafeteria","Dylan’s cafe"};


    ListView cafeBrandListView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        cafeBrandListView=findViewById(R.id.top1);


        //Adapter
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,android.R.id.text1,cafe_names);
        cafeBrandListView.setAdapter(adapter);


    }
}
