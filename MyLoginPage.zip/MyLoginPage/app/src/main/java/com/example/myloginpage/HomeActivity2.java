package com.example.myloginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeActivity2 extends AppCompatActivity {

    Button listBtn,customBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home2);


        listBtn=findViewById(R.id.listbtn);
        customBtn=findViewById(R.id.listbtn2);

        listBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view){
                Intent intent=new Intent(HomeActivity2.this,ListActivity.class);
                startActivity(intent);
            }
        });

        customBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view){
                Intent intent=new Intent(HomeActivity2.this,CafeActivity.class);
                startActivity(intent);
            }
        });



    }
}