//package com.example.myloginpage;
//
/*import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class ImagesActivity extends AppCompatActivity {

    String[] cafe_names = {"Jim Morrison Cafe", "Landour Bakehouse", "Beatles Cafe", "Wake and Bake Cafe",
            "Glenary's", "Cafe 1947", "Cafe Chica", "Illiterati Coffee", "The Sakley’s", "Cafe Simla Times", "Little Llama Cafe",
            "Cloud Coffee", "Rinchen Cafeteria", "Dylan’s cafe"};


        String[] item1 = {"Hot Beverages", "Cold Beverages", "Breakfast Cereals", "Sandwich", "Soups", "Noodles", "Appetizers"};

        Integer[] images1 = {R.drawable.jim,R.drawable.land,R.drawable.beat,R.drawable.wake,R.drawable.glenary,
                R.drawable.nine,R.drawable.chica,R.drawable.illeterati,R.drawable.sakley,
                R.drawable.simla,R.drawable.little,R.drawable.cloud,R.drawable.rinchen,R.drawable.dylan};

        String[] item2 = {"Breads", "Loaf", "Cookies", "Toasties", "Crepes"};

        String[] item3 = {"Soups", "Salads", "Burgers", "Pasta", "Sandwich"};

        String[] item4 = {"Hot Beverages", "Cold Beverages", "Breakfast Cereals", "Sandwich", "Soups", "Noodles", "Appetizers"};

        String[] item5 = {"Breads", "Loaf", "Cookies", "Toasties", "Crepes"};

        String[] item6 = {"Soups", "Salads", "Burgers", "Pasta", "Sandwich"};

        String[] item7 = {"Hot Beverages", "Cold Beverages", "Breakfast Cereals", "Sandwich", "Soups", "Noodles", "Appetizers"};

        String[] item8 = {"Breads", "Loaf", "Cookies", "Toasties", "Crepes"};

        String[] item9 = {"Soups", "Salads", "Burgers", "Pasta", "Sandwich"};


        String[] item10 = {"Breads", "Loaf", "Cookies", "Toasties", "Crepes"};

        String[] item11 = {"Soups", "Salads", "Burgers", "Pasta", "Sandwich"};

        String[] item12 = {"Hot Beverages", "Cold Beverages", "Breakfast Cereals", "Sandwich", "Soups", "Noodles", "Appetizers"};

        String[] item13 = {"Breads", "Loaf", "Cookies", "Toasties", "Crepes"};

        String[] item14 = {"Soups", "Salads", "Burgers", "Pasta", "Sandwich"};

        ListView cafeImagesListView;
        @SuppressLint("WrongViewCast")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_images);

            cafeImagesListView = findViewById(R.id.pic_name);
            CafeAdapter adapter = new CafeAdapter(this, item1, images1);
            cafeImagesListView.setAdapter(adapter);

            cafeImagesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    int position=i;
                    String cafeselected=cafeImagesListView.getItemAtPosition(position).toString();
                    Toast.makeText(ImagesActivity.this, "Selected"+" "+cafeselected, Toast.LENGTH_SHORT).show();

                    String[] items={""};
                    if(position==0){
                        items=item1;
                    } else if (position==1) {
                        items=item2;
                    } else if (position==2) {
                        items=item3;
                    } else if (position==3) {
                        items=item4;
                    }
                    else if (position==4) {
                        items=item5;
                    } else if (position==5) {
                        items=item6;
                    }
                    else if (position==6) {
                        items=item7;
                    } else if (position==7) {
                        items=item8;
                    }
                    else if (position==8) {
                        items=item9;
                    } else if (position==9) {
                        items=item10;
                    }else if (position==10) {
                        items=item11;
                    }
                    else if (position==11) {
                        items=item12;
                    } else if (position==12) {
                        items=item13;
                    }
                    else if (position==13) {
                        items=item14;
                    }
                    Intent intent=new Intent(ImagesActivity.this,CafeSubCategory.class);
                    intent.putExtra("items",items);
                    intent.putExtra("cafe_names",cafeselected);
                    startActivity(intent);
                }
            });
        }
    }
*/