package com.example.myloginpage;


import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.MediaDataSource;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

public class CafeAdapter extends ArrayAdapter<String> {
    private final Context context;
    private final String[] cafes;

    private String[] logos;


    public CafeAdapter(Context context, String[] cafes, String[] logos) {
        super(context, R.layout.customised_list, cafes);

        this.context = context;
        this.cafes = cafes;
        this.logos = logos;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item = inflater.inflate(R.layout.customised_list, null, true);


        ImageView logoImg = item.findViewById(R.id.cafe_image);
        TextView cafeName = item.findViewById(R.id.cafe_name);

        cafeName.setText(cafes[position]);

       //picasso for logoimg
        File file=new File(logos[position]).getAbsoluteFile();
        Picasso.get().load(file).into(logoImg);

        return item;
    }
}
