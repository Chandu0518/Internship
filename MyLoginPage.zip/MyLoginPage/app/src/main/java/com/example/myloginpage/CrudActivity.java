package com.example.myloginpage;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;


public class CrudActivity extends AppCompatActivity {

    TextView purposeTv;
    EditText idEd, nameEd, statusEd,descEd;
    Button addBtn,deleteBtn,UpdateBtn,ReadBtn,UploadBtn;
    ImageView previewBtn;

    OperationSqlite operationSqlite;

    public final static int pic_id=1234;

    String Pathaddress=" ";
    String[] cafe_names={};
    Spinner categorySpinner,subcategorySpinner;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crud);
        purposeTv=findViewById(R.id.operations_tv);
        categorySpinner=findViewById(R.id.category_spinner);
        subcategorySpinner=findViewById(R.id.subcategory_spinner);
        OperationSqlite OperationSqlite = new OperationSqlite((this));
        idEd=findViewById(R.id.operationid_et);
        nameEd=findViewById(R.id.operationname_et);
        statusEd=findViewById(R.id.operationstatus_et);
        descEd=findViewById(R.id.operationdesc_et);

        addBtn=findViewById(R.id.addBtn);
        deleteBtn=findViewById(R.id.deleteBtn);
        UpdateBtn=findViewById(R.id.updateBtn);
        ReadBtn=findViewById(R.id.readBtn);
        UploadBtn=findViewById(R.id.upload_btn);
        previewBtn=findViewById(R.id.operation_imageview);


        String purpose=getIntent().getStringExtra("purpose");
        purposeTv.setText(purpose);


        if (purpose.equals("subcategory")){
            categorySpinner.setVisibility(View.VISIBLE);
            idEd.setEnabled(false);
        }
        // spinner
        String condition=null;
        ArrayList<String> arrayList=new ArrayList<String>();
        ArrayList<String> categoryIDList=new ArrayList<String>();
        Cursor result=OperationSqlite.listData("category",condition);
        if (result.getCount()==0){
            arrayList.add("No Data");
        }
        while (result.moveToNext()){
            arrayList.add(result.getString(1));
            categoryIDList.add(result.getString(0));
        }
        //name string array
        String[] cafe_names = new String[arrayList.size()];
        for (int i=0; i<arrayList.size(); i++){
            cafe_names[i]=arrayList.get(i);
        }

        ArrayAdapter adapter=new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cafe_names);
        categorySpinner.setAdapter(adapter);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                int position=i;
                idEd.setText(categoryIDList.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //end of spinner


        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=nameEd.getText().toString();
                Integer status=Integer.parseInt(statusEd.getText().toString());
                String id=idEd.getText().toString();

                boolean isInserted=OperationSqlite.insertData(purpose,id,name, String.valueOf(Pathaddress), Integer.valueOf(Pathaddress), String.valueOf(status));
                if (isInserted){
                    Toast.makeText(CrudActivity.this, " "+purpose+"Added Successfully", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(CrudActivity.this, "Failed To Add", Toast.LENGTH_SHORT).show();
                }
            }
        });
        UploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent open_camera=new Intent();
                open_camera.setType("image/*");
                open_camera.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(open_camera,"Select Image"),pic_id);
            }
        });
        UpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=nameEd.getText().toString();
                Integer status=Integer.parseInt(statusEd.getText().toString());
                String id=idEd.getText().toString();
                String description=descEd.getText().toString();

                boolean isUpdated=OperationSqlite.insertData(id,purpose,name,(Pathaddress),status,description);
                if (isUpdated){
                    Toast.makeText(CrudActivity.this, " "+purpose+"Updated Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(CrudActivity.this,CrudActivity.class);
                    intent.putExtra("purpose",purpose);
                    startActivity(intent);
                }else {
                    Toast.makeText(CrudActivity.this, "Failed To Update", Toast.LENGTH_SHORT).show();
                }
            }
        });
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id=idEd.getText().toString();
                Integer isDeleted=OperationSqlite.deleteData(id,purpose);
                if(isDeleted>0){
                    Toast.makeText(CrudActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(CrudActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestcode, int resultcode, @Nullable Intent data){
        super.onActivityResult(requestcode,resultcode,data);

        if(requestcode==pic_id){
            Uri selectedimg=data.getData();
            previewBtn.setImageURI(selectedimg);

            Uri uri=data.getData();
            File file=new File(uri.getPath());
            final String[] split=file.getPath().split(":");
            String filePath = split[1];
            Log.i("path Image",filePath);
            Pathaddress=filePath;
        }
    }
}