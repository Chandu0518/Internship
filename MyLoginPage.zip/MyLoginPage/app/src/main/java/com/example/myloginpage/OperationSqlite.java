package com.example.myloginpage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class OperationSqlite extends SQLiteOpenHelper {

    public final static String DATABASE_NAME = "premiere.db";
    public final static String CategoryTable="category";
    public final static String SubCategoryTable="subcategory";
    public final static String CafeTable="cafetable";

    //Columns for Category

    public final static String C_1="ID";
    public final static String C_2="NAME";
    public final static String C_3="IMAGE";
    public final static String C_4="STATUS";
    public final static String C_5="DESCRIPTION";

    //Columns for Sub Category

    public final static String S_1="ID";
    public final static String S_2="CATEGORY_ID";
    public final static String S_3="NAME";
    public final static String S_4="IMAGE";
    public final static String S_5="STATUS";

    //COlumns for Cafe Table

    public final static String F_1="ID";
    public final static String F_2="CATEGORY_ID";
    public final static String F_3="NAME";
    public final static String F_4="IMAGE";
    public final static String F_5="STATUS";


    public OperationSqlite(Context context){
        super(context,DATABASE_NAME,null,1);
}

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " +CategoryTable+"(ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,IMAGE TEXT,STATUS INTEGER,DESCRIPTION TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " +SubCategoryTable+"(ID INTEGER PRIMARY KEY AUTOINCREMENT,CATEGORYID INTEGER,NAME TEXT,IMAGE TEXT,STATUS INTEGER)");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " +CafeTable+"(ID INTEGER PRIMARY KEY AUTOINCREMENT,CATEGORYID INTEGER,NAME TEXT,IMAGE TEXT,STATUS INTEGER)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+CategoryTable);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+SubCategoryTable);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+CafeTable);
        onCreate(sqLiteDatabase);

    }
    public boolean insertData(String purpose, String name, String image, String s, Integer status, String description){
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(C_2,name);
        cv.put(C_3,image);
        cv.put(C_4,status);
        cv.put(C_5,description);
        String tablename="";
        if (purpose.equals("category")){
            tablename=CategoryTable;
        } else if (purpose.equals("subcategory")) {
            tablename=SubCategoryTable;
        }else {
            tablename=CafeTable;
        }
        long result=database.insert(tablename,null,cv);
        if (result==-1){
            return false;
        }else
            return true;
    }
    public boolean updateData(String id,String purpose,String name,String image,Integer status,String description) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_2, name);
        cv.put(C_3, image);
        cv.put(C_4, status);
        cv.put(C_5, description);
        String tablename = "";
        if (purpose.equals("category")) {
            tablename = CategoryTable;
        } else if (purpose.equals("subcategory")) {
            tablename = SubCategoryTable;
        }

        database.update(tablename, cv, "ID=?", new String[]{id});
        return true;
    }
    public int deleteData(String id, String purpose) {
        SQLiteDatabase database = this.getWritableDatabase();
        String tablename = "";
        if (purpose.equals("category")) {
            tablename = CategoryTable;
        } else if (purpose.equals("subcategory")) {
            tablename = SubCategoryTable;
        }
        return database.delete(tablename, "ID=?", new String[]{id});
    }
    public Cursor listData(String purpose,String condition){
        SQLiteDatabase database=this.getWritableDatabase();
        String tablename=purpose;
        String where=condition;
        String query="";
        if (purpose.equals("category")){
            tablename=CategoryTable;
        }else if(purpose.equals("subcategory")){
            tablename=SubCategoryTable;
        }
        else {
            tablename=CafeTable;
        }
        if (where!=null){
            query="SELECT * FROM "+tablename+" WHERE ID='"+where+"'";
        }else {
            query="SELECT * FROM "+tablename;
        }
        Cursor cursor=database.rawQuery(query,null);
        return cursor;
    }

}
