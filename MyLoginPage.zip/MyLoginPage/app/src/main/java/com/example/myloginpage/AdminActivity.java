package com.example.myloginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminActivity extends AppCompatActivity {

    Button CatAddBtn,CatUpdateBtn,CatDeleteBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        CatAddBtn=findViewById(R.id.adminbtn);
        CatUpdateBtn=findViewById(R.id.adminbtn2);
        CatDeleteBtn=findViewById(R.id.adminbtn3);


        CatAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCategoryOperation();
            }
        });
        CatDeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               openCategoryOperation();
            }
        });
        CatUpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               openCategoryOperation();
            }
        });

    }

    private void openSubcategoryOperation() {
        Intent intent=new Intent(AdminActivity.this,CrudActivity.class);
        intent.putExtra("purpose","subcategory");
        startActivity(intent);
    }

    private void openCategoryOperation(){
        Intent intent=new Intent(AdminActivity.this,CrudActivity.class);
        intent.putExtra("purpose","category");
        startActivity(intent);
    }
}