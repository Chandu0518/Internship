package com.example.myloginpage;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class CafeActivity extends AppCompatActivity {

    String[] cafe_names = {};
    String[] logos = {};

    ListView cafeBrandListView;

    OperationSqlite operationSqlite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe);
        operationSqlite = new OperationSqlite(this);

        //set ids

        cafeBrandListView = findViewById(R.id.custom_list);
        String purpose = "category";
        readCategory(purpose);


        CafeAdapter adapter = new CafeAdapter(this, cafe_names, logos);
        cafeBrandListView.setAdapter(adapter);

        cafeBrandListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int position = i;
                String cafeSelected = cafeBrandListView.getItemAtPosition(position).toString();
                Toast.makeText(CafeActivity.this, "Selected: " + cafeSelected, Toast.LENGTH_SHORT).show();


                //Intent intent=new Intent(CafeActivity.this,CafeSubCategory.class);
                //intent.putExtra("items",items);
                //intent.putExtra("CafeName",cafeSelected);
                //intent.putExtra("images",logosarray);
                //startActivity(intent);
            }
        });
    }

    private void readCategory(String purpose) {
        String condition=null;
        Cursor result = operationSqlite.listData(purpose,condition);
        if (result.getCount() == 0) {
           displayMessage("Data","No data found");
        }
        ArrayList<String>arrayList=new ArrayList<String>();
        ArrayList<String>logoArray=new ArrayList<>();
        while (result.moveToNext()) {
            arrayList.add(result.getString(1));
            logoArray.add(result.getString(2));
            Log.i("image db:",result.getString(2));
        }

        //new string array
        cafe_names=new String[arrayList.size()];
        for (int i=0; i<arrayList.size(); i++){
            cafe_names[i]=arrayList.get(i);
        }

        //logo string array
        logos=new String[logoArray.size()];
        for (int i=0;i<logoArray.size();i++){
            logos[i]=logoArray.get(i);
            Log.i("image address"+i,logoArray.get(i));
        }

    }


    private void displayMessage(String data, String message) {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.create();
        builder.setCancelable(true);
        builder.setTitle(data);
        builder.setMessage(message);
        builder.show();

    }

    public static int[] toint(Integer[] WrapperArray){
        int[] newArray=new int[WrapperArray.length];
        for (int i=0;i<WrapperArray.length;i++){
            newArray[i] = WrapperArray[i];
        }
        return newArray;
    }

}