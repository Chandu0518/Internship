package com.example.myloginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText mobileEd,passwordEd;
    Button loginBtn,adminBtn;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    Boolean isLogin=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        preferences=getSharedPreferences("pref",MODE_PRIVATE);
        editor=preferences.edit();
        checkLogin();



        mobileEd=findViewById(R.id.mobile_et);
        passwordEd=findViewById(R.id.password_et);
        loginBtn=findViewById(R.id.loginbtn);
        adminBtn=findViewById(R.id.adminbtn);

        adminBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,AdminActivity.class);
                startActivity(intent);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view){
                //logic
                String mobile=mobileEd.getText().toString();
                String pass=passwordEd.getText().toString();

                if(!mobile.isEmpty()){
                    //continue
                    if (!pass.isEmpty()){
                        //continue
                        if (mobile.length()==10){
                            if (mobile.equals("7569846267")) {
                                if (pass.equals("chandu")) {
                                    //success
                                    editor.putBoolean("isLogin",true);
                                    editor.commit();
                                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                                    Intent intent=new Intent(MainActivity.this,HomeActivity2.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    passwordEd.setError("Invalid Password");
                                }
                            }else{
                                    mobileEd.setError("Invalid Mobile Number");
                                }
                        }else {
                                mobileEd.setError("Please Enter 10 digit Mobile Number");
                            }
                    }else {
                            Toast.makeText(MainActivity.this, "Password is Required", Toast.LENGTH_SHORT).show();
                            passwordEd.setError("Password is Required");
                        }

                }else {
                        //empty
                        Toast.makeText(MainActivity.this, "Mobile Number is Required", Toast.LENGTH_SHORT).show();
                        mobileEd.setError("Mobile Number is Required");
                    }
                }
            });
            }




    private void checkLogin() {
        isLogin=preferences.getBoolean("isLogin",false);
        if(isLogin==true){
            Intent intent=new Intent(MainActivity.this,HomeActivity2.class);
            startActivity(intent);
            finish();
        }
    }

}